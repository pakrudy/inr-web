<?php

namespace App\Http\Controllers;

use App\Models\Recommendation;
use App\Models\RecommendationCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class RecommendationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $recommendations = Auth::user()->recommendations()->with('transactions')->latest()->get();

        foreach ($recommendations as $recommendation) {
            $pendingTransactions = $recommendation->transactions->where('status', 'pending');
            $recommendation->has_pending_initial_payment = $pendingTransactions->where('transaction_type', 'initial')->isNotEmpty();
            $recommendation->has_pending_upgrade_payment = $pendingTransactions->where('transaction_type', 'upgrade')->isNotEmpty();
            $recommendation->has_pending_renewal_payment = $pendingTransactions->where('transaction_type', 'renewal')->isNotEmpty();
        }

        return view('customer.recommendations.index', compact('recommendations'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = RecommendationCategory::all();
        return view('customer.recommendations.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'recommendation_category_id' => 'required|exists:recommendation_categories,id',
            'place_name' => 'required|string|max:255',
            'address' => 'nullable|string|max:255',
            'map_embed_code' => 'nullable|string',
            'description' => 'nullable|string',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('photo')) {
            $validated['photo'] = $request->file('photo')->store('recommendations', 'public');
        }

        Auth::user()->recommendations()->create($validated);

        return redirect()->route('customer.recommendations.index')->with('success', 'Rekomendasi berhasil diajukan.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Recommendation $recommendation)
    {
        if (Auth::id() !== $recommendation->user_id) {
            abort(403);
        }

        $recommendation->load('transactions');

        $pendingTransactions = $recommendation->transactions->where('status', 'pending');
        $recommendation->has_pending_initial_payment = $pendingTransactions->where('transaction_type', 'initial')->isNotEmpty();
        $recommendation->has_pending_upgrade_payment = $pendingTransactions->where('transaction_type', 'upgrade')->isNotEmpty();
        $recommendation->has_pending_renewal_payment = $pendingTransactions->where('transaction_type', 'renewal')->isNotEmpty();

        return view('customer.recommendations.show', compact('recommendation'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Recommendation $recommendation)
    {
        if (Auth::id() !== $recommendation->user_id) {
            abort(403);
        }

        if ($recommendation->status !== 'pending') {
            return redirect()->route('customer.recommendations.show', $recommendation)->with('error', 'Rekomendasi yang sudah aktif tidak dapat diedit.');
        }

        $categories = RecommendationCategory::all();
        return view('customer.recommendations.edit', compact('recommendation', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Recommendation $recommendation)
    {
        if (Auth::id() !== $recommendation->user_id) {
            abort(403);
        }

        if ($recommendation->status !== 'pending') {
            return redirect()->route('customer.recommendations.show', $recommendation)->with('error', 'Rekomendasi yang sudah aktif tidak dapat diedit.');
        }

        $validated = $request->validate([
            'recommendation_category_id' => 'required|exists:recommendation_categories,id',
            'place_name' => 'required|string|max:255',
            'address' => 'nullable|string|max:255',
            'map_embed_code' => 'nullable|string',
            'description' => 'nullable|string',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('photo')) {
            // Delete old photo if it exists
            if ($recommendation->photo) {
                Storage::disk('public')->delete($recommendation->photo);
            }
            $validated['photo'] = $request->file('photo')->store('recommendations', 'public');
        }

        $recommendation->update($validated);

        return redirect()->route('customer.recommendations.show', $recommendation)->with('success', 'Rekomendasi berhasil diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Recommendation $recommendation)
    {
        if (Auth::id() !== $recommendation->user_id) {
            abort(403);
        }
        
        // Delete photo if it exists
        if ($recommendation->photo) {
            Storage::disk('public')->delete($recommendation->photo);
        }

        $recommendation->delete();

        return redirect()->route('customer.recommendations.index')->with('success', 'Rekomendasi berhasil dihapus.');
    }
}
