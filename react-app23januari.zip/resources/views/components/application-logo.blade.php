<img src="https://inr.or.id/storage/icons/logo-inr-web-130.png" alt="INR Logo" {{ $attributes }} />
