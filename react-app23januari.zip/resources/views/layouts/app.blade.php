<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Indonesian Records') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])

        {{-- TinyMCE --}}
        {{-- TODO: Ganti no-api-key dengan API Key Anda dari tiny.cloud --}}
        <script src="https://cdn.tiny.cloud/1/3quyp8se3ji90a9w6gcn9jzobmdztm8ak1rrx3othsuid0vw/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>


    </head>
        <body class="font-sans antialiased">
            <div class="min-h-screen bg-gray-100 flex flex-col">
                @include('layouts.navigation')
    
                <!-- Page Heading -->
                @isset($header)
                    <header class="bg-white shadow">
                        <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                            {{ $header }}
                        </div>
                    </header>
                @endisset
    
                @if (session('success'))
                    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-4">
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                            <strong class="font-bold">Success!</strong>
                            <span class="block sm:inline">{{ session('success') }}</span>
                        </div>
                    </div>
                @endif
    
                <!-- Page Content -->
                <main class="flex-grow">
                    {{ $slot }}
                </main>
    
                <footer class="bg-white mt-8 py-4 text-center text-sm text-gray-500 border-t">
                    <p>&copy; {{ date('Y') }} {{ config('app.name', 'Indonesian Legacy Records') }}. All Rights Reserved.</p>
                </footer>
            </div>
            <script>
                tinymce.init({
                    selector: 'textarea.wysiwyg',
                    plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount',
                    toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | align lineheight | numlist bulllist indent outdent | emoticons charmap | removeformat',
                });
            </script>
            @stack('scripts')
        </body>
    </html>
