<?php if (isset($component)) { $__componentOriginalfcad64dfa01b029ba835611407e96dec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfcad64dfa01b029ba835611407e96dec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Pembayaran Rekomendasi')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">
                        <?php echo e(__('Ringkasan Pembayaran untuk Rekomendasi:')); ?> <?php echo e($model->place_name); ?>

                    </h3>

                    <?php if($hasPendingPayment): ?>
                        <div class="p-4 mb-4 text-sm text-blue-800 rounded-lg bg-blue-50" role="alert">
                            <span class="font-medium">Pembayaran Tertunda:</span> Anda sudah memiliki permintaan pembayaran untuk item ini yang sedang menunggu konfirmasi. Silakan periksa halaman transaksi Anda atau hubungi admin.
                        </div>
                        <div class="mt-6">
                            <a href="<?php echo e(route('customer.recommendations.index')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700">
                                <?php echo e(__('Kembali ke Daftar Rekomendasi')); ?>

                            </a>
                        </div>
                    <?php else: ?>
                        <?php
                            $amount = 0;
                            $description = '';
                            if ($paymentType === 'initial') {
                                $amount = $settings['payment.recommendation.initial'] ?? 50000;
                                $description = 'Pembayaran awal untuk aktivasi Rekomendasi.';
                            } elseif ($paymentType === 'upgrade') {
                                $amount = $settings['payment.recommendation.upgrade'] ?? 25000;
                                $description = 'Pembayaran untuk upgrade Rekomendasi menjadi Terindeks (badge "recommended").';
                            } elseif ($paymentType === 'renewal') {
                                $amount = $settings['payment.recommendation.renewal'] ?? 25000;
                                $description = 'Pembayaran untuk perpanjangan Rekomendasi selama 1 tahun.';
                            }
                        ?>

                        <p class="mt-1 text-sm text-gray-600 mb-4"><?php echo e($description); ?></p>

                        <div class="mb-6">
                            <p class="text-xl font-bold text-gray-900"><?php echo e(__('Jumlah yang Harus Dibayar:')); ?> Rp <?php echo e(number_format($amount, 0, ',', '.')); ?></p>
                        </div>

                        <form method="POST" action="<?php echo e(route('customer.recommendations.payment.store', $model)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="payment_type" value="<?php echo e($paymentType); ?>">
                            
                            <div class="flex items-center gap-4">
                                <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(__('Konfirmasi & Buat Transaksi')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfcad64dfa01b029ba835611407e96dec)): ?>
<?php $attributes = $__attributesOriginalfcad64dfa01b029ba835611407e96dec; ?>
<?php unset($__attributesOriginalfcad64dfa01b029ba835611407e96dec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfcad64dfa01b029ba835611407e96dec)): ?>
<?php $component = $__componentOriginalfcad64dfa01b029ba835611407e96dec; ?>
<?php unset($__componentOriginalfcad64dfa01b029ba835611407e96dec); ?>
<?php endif; ?>
<?php /**PATH D:\xampp8.2\htdocs\react-app\resources\views/customer/recommendations/payment/create.blade.php ENDPATH**/ ?>