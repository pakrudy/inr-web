<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($page->title); ?> - Indonesian Legacy Records</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="antialiased bg-gray-50">

    <?php if (isset($component)) { $__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d)): ?>
<?php $attributes = $__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d; ?>
<?php unset($__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d)): ?>
<?php $component = $__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d; ?>
<?php unset($__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d); ?>
<?php endif; ?>

    <main class="py-16">
        <div class="container mx-auto px-4">
            <article class="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8">
                <h1 class="text-4xl font-extrabold text-gray-900 mb-8"><?php echo e($page->title); ?></h1>
                
                <div class="prose max-w-none text-gray-800">
                    <?php echo $page->content; ?>

                </div>

            </article>
        </div>
    </main>

    <footer class="bg-gray-800 text-white py-6 mt-12 text-center">
        <p>&copy; 2026 INR Team. All rights reserved.</p>
    </footer>

</body>
</html>
<?php /**PATH D:\xampp8.2\htdocs\react-app\resources\views/pages/show.blade.php ENDPATH**/ ?>