<?php if (isset($component)) { $__componentOriginalfcad64dfa01b029ba835611407e96dec = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfcad64dfa01b029ba835611407e96dec = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Rekomendasi Saya')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex justify-end mb-4">
                        <a href="<?php echo e(route('customer.recommendations.create')); ?>" class="inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                            <?php echo e(__('Ajukan Rekomendasi Baru')); ?>

                        </a>
                    </div>

                    <?php if($recommendations->isEmpty()): ?>
                        <p class="text-gray-600"><?php echo e(__('Anda belum memiliki rekomendasi yang diajukan.')); ?></p>
                    <?php else: ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Nama Tempat')); ?>

                                        </th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Kategori')); ?>

                                        </th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Status')); ?>

                                        </th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Terindeks')); ?>

                                        </th>
                                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            <?php echo e(__('Masa Aktif')); ?>

                                        </th>
                                        <th scope="col" class="relative px-6 py-3">
                                            <span class="sr-only"><?php echo e(__('Aksi')); ?></span>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                <?php echo e($recommendation->place_name); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo e($recommendation->recommendationCategory->name ?? '-'); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php if(($recommendation->status === 'pending' && $recommendation->has_pending_initial_payment) || ($recommendation->status === 'expired' && $recommendation->has_pending_renewal_payment)): ?>
                                                    <span class="text-yellow-800"><?php echo e(__('Waiting Admin Approval')); ?></span>
                                                <?php else: ?>
                                                    <?php echo e(ucfirst($recommendation->status)); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php if($recommendation->is_indexed): ?>
                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                                        <?php echo e(__('Ya')); ?>

                                                    </span>
                                                <?php elseif($recommendation->has_pending_upgrade_payment): ?>
                                                    <span class="text-yellow-800"><?php echo e(__('Waiting Admin Approval')); ?></span>
                                                <?php else: ?>
                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                        <?php echo e(__('Tidak')); ?>

                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <div>
                                                    <span class="font-semibold">Aktif (R1):</span> <?php echo e($recommendation->expires_at ? $recommendation->expires_at->format('d M Y') : '-'); ?>

                                                </div>
                                                <div>
                                                    <span class="font-semibold">Indeks (R2):</span> <?php echo e($recommendation->indexed_expires_at ? $recommendation->indexed_expires_at->format('d M Y') : '-'); ?>

                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                <a href="<?php echo e(route('customer.recommendations.show', $recommendation)); ?>" class="text-indigo-600 hover:text-indigo-900"><?php echo e(__('Lihat')); ?></a>

                                                
                                                <?php if($recommendation->status === 'pending' && !$recommendation->has_pending_initial_payment): ?>
                                                    <a href="<?php echo e(route('customer.recommendations.payment.create', $recommendation)); ?>" class="ml-3 text-green-600 hover:text-green-900"><?php echo e(__('Bayar')); ?></a>
                                                    <a href="<?php echo e(route('customer.recommendations.edit', $recommendation)); ?>" class="ml-3 text-indigo-600 hover:text-indigo-900"><?php echo e(__('Edit')); ?></a>
                                                
                                                
                                                <?php elseif($recommendation->status === 'active' && !$recommendation->is_indexed && !$recommendation->has_pending_upgrade_payment): ?>
                                                    <a href="<?php echo e(route('customer.recommendations.payment.create', ['recommendation' => $recommendation, 'type' => 'upgrade'])); ?>" class="ml-3 text-blue-600 hover:text-blue-900"><?php echo e(__('Upgrade')); ?></a>
                                                
                                                
                                                <?php elseif($recommendation->status === 'expired' && !$recommendation->has_pending_renewal_payment): ?>
                                                     <a href="<?php echo e(route('customer.recommendations.payment.create', ['recommendation' => $recommendation, 'type' => 'renewal_r1'])); ?>" class="ml-3 text-orange-600 hover:text-orange-900"><?php echo e(__('Perpanjang Aktif (R1)')); ?></a>
                                                <?php endif; ?>
                                                
                                                <?php if($recommendation->status === 'active'): ?>
                                                    
                                                    <?php if($recommendation->expires_at && $recommendation->expires_at->isPast() || now()->diffInDays($recommendation->expires_at, false) <= 30): ?>
                                                        <a href="<?php echo e(route('customer.recommendations.payment.create', ['recommendation' => $recommendation, 'type' => 'renewal_r1'])); ?>" class="ml-3 text-orange-600 hover:text-orange-900"><?php echo e(__('Perpanjang Aktif (R1)')); ?></a>
                                                    <?php endif; ?>

                                                    
                                                    <?php if($recommendation->is_indexed && $recommendation->indexed_expires_at && ($recommendation->indexed_expires_at->isPast() || now()->diffInDays($recommendation->indexed_expires_at, false) <= 30)): ?>
                                                        <a href="<?php echo e(route('customer.recommendations.payment.create', ['recommendation' => $recommendation, 'type' => 'renewal_r2'])); ?>" class="ml-3 text-purple-600 hover:text-purple-900"><?php echo e(__('Perpanjang Indeks (R2)')); ?></a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfcad64dfa01b029ba835611407e96dec)): ?>
<?php $attributes = $__attributesOriginalfcad64dfa01b029ba835611407e96dec; ?>
<?php unset($__attributesOriginalfcad64dfa01b029ba835611407e96dec); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfcad64dfa01b029ba835611407e96dec)): ?>
<?php $component = $__componentOriginalfcad64dfa01b029ba835611407e96dec; ?>
<?php unset($__componentOriginalfcad64dfa01b029ba835611407e96dec); ?>
<?php endif; ?>
<?php /**PATH D:\xampp8.2\htdocs\react-app\resources\views/customer/recommendations/index.blade.php ENDPATH**/ ?>