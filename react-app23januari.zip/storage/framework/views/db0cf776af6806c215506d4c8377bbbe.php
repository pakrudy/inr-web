<nav x-data="{ open: false }" class="bg-white shadow-sm">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
            <!-- Logo -->
            <div class="flex-shrink-0">
                <a href="/">
                    <img src="https://inr.or.id/storage/icons/logo-inr-web-130.png" alt="Logo Organisasi" class="h-10 w-auto">
                </a>
            </div>

            <!-- Desktop Menu -->
            <div class="hidden sm:flex sm:items-center sm:space-x-6">
                <a href="<?php echo e(route('dashboard')); ?>" class="text-gray-600 hover:text-indigo-600">Beranda</a>
                
                
                <a href="<?php echo e(route('customer.profile.edit')); ?>" class="text-gray-600 hover:text-indigo-600">Edit Profil</a>
                
                <div x-data="{ open: false }" @click.away="open = false" class="relative">
                    <button @click="open = !open" class="inline-flex items-center text-gray-600 hover:text-indigo-600">
                        <span>Legacy</span>
                        <svg class="ms-1 -me-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div x-show="open"
                         x-transition:enter="transition ease-out duration-200"
                         x-transition:enter-start="opacity-0 scale-95"
                         x-transition:enter-end="opacity-100 scale-100"
                         x-transition:leave="transition ease-in duration-75"
                         x-transition:leave-start="opacity-100 scale-100"
                         x-transition:leave-end="opacity-0 scale-95"
                         class="absolute z-50 mt-2 w-48 rounded-md shadow-lg origin-top-right right-0"
                         style="display: none;"
                         @click="open = false">
                        <div class="rounded-md ring-1 ring-black ring-opacity-5 py-1 bg-white">
                            <a href="<?php echo e(route('customer.legacies.index')); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Lihat Legacy</a>
                            <a href="<?php echo e(route('customer.legacies.create')); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Ajukan Legacy</a>
                        </div>
                    </div>
                </div>

                <div x-data="{ open: false }" @click.away="open = false" class="relative">
                    <button @click="open = !open" class="inline-flex items-center text-gray-600 hover:text-indigo-600">
                        <span>Rekomendasi</span>
                        <svg class="ms-1 -me-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div x-show="open"
                         x-transition:enter="transition ease-out duration-200"
                         x-transition:enter-start="opacity-0 scale-95"
                         x-transition:enter-end="opacity-100 scale-100"
                         x-transition:leave="transition ease-in duration-75"
                         x-transition:leave-start="opacity-100 scale-100"
                         x-transition:leave-end="opacity-0 scale-95"
                         class="absolute z-50 mt-2 w-48 rounded-md shadow-lg origin-top-right right-0"
                         style="display: none;"
                         @click="open = false">
                        <div class="rounded-md ring-1 ring-black ring-opacity-5 py-1 bg-white">
                            <a href="<?php echo e(route('customer.recommendations.index')); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Lihat Rekomendasi</a>
                            <a href="<?php echo e(route('customer.recommendations.create')); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Ajukan Rekomendasi</a>
                        </div>
                    </div>
                </div>

                <!-- Logout -->
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline-block">
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                        this.closest('form').submit();"
                        class="text-gray-600 hover:text-indigo-600">
                        <?php echo e(__('Log Out')); ?>

                    </a>
                </form>
            </div>

            <!-- Hamburger -->
            <div class="-me-2 flex items-center sm:hidden">
                <button @click="open = ! open" class="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none">
                    <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                        <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <!-- Responsive Menu -->
    <div :class="{'block': open, 'hidden': ! open}" class="hidden sm:hidden">
        <div class="pt-2 pb-3 space-y-1">
            <a href="<?php echo e(route('dashboard')); ?>" class="block ps-3 pe-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300">Beranda</a>
        </div>
        <div class="pt-4 pb-3 border-t border-gray-200">
            <div class="px-4">
                <div class="font-medium text-base text-gray-800"><?php echo e(Auth::user()->name); ?></div>
                <div class="font-medium text-sm text-gray-500"><?php echo e(Auth::user()->email); ?></div>
            </div>
            <div class="mt-3 space-y-1">
                <a href="<?php echo e(route('customer.profile.edit')); ?>" class="block ps-3 pe-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300">Edit Profil</a>
                
                <div class="border-t border-gray-200"></div>
                <div class="px-4 mt-3">
                    <div class="font-medium text-base text-gray-800">Legacy</div>
                </div>
                <a href="<?php echo e(route('customer.legacies.index')); ?>" class="block ps-3 pe-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300">Lihat Legacy</a>
                <a href="<?php echo e(route('customer.legacies.create')); ?>" class="block ps-3 pe-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300">Ajukan Legacy</a>
                
                <div class="border-t border-gray-200"></div>
                <div class="px-4 mt-3">
                    <div class="font-medium text-base text-gray-800">Rekomendasi</div>
                </div>
                <a href="<?php echo e(route('customer.recommendations.index')); ?>" class="block ps-3 pe-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300">Lihat Rekomendasi</a>
                <a href="<?php echo e(route('customer.recommendations.create')); ?>" class="block ps-3 pe-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300">Ajukan Rekomendasi</a>
                
                <div class="border-t border-gray-200"></div>

                <!-- Authentication -->
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                        this.closest('form').submit();"
                            class="block ps-3 pe-4 py-2 border-l-4 border-transparent text-base font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-50 hover:border-gray-300">
                        <?php echo e(__('Log Out')); ?>

                    </a>
                </form>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\xampp8.2\htdocs\react-app\resources\views/components/customer-nav.blade.php ENDPATH**/ ?>