<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($recommendation->place_name); ?> - Recommendation Index</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="antialiased bg-gray-50">

    <?php if (isset($component)) { $__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d)): ?>
<?php $attributes = $__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d; ?>
<?php unset($__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d)): ?>
<?php $component = $__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d; ?>
<?php unset($__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d); ?>
<?php endif; ?>

    <main class="py-16">
        <div class="container mx-auto px-4">
            <!-- Breadcrumb -->
            <nav class="flex mb-8 text-gray-500 text-sm" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-3">
                    <li class="inline-flex items-center">
                        <a href="/" class="hover:text-gray-900">Beranda</a>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <svg class="w-3 h-3 text-gray-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
                            </svg>
                            <a href="<?php echo e(route('recommendations.index')); ?>" class="hover:text-gray-900 ml-1 md:ml-2">Recommendation Index</a>
                        </div>
                    </li>
                    <li aria-current="page">
                        <div class="flex items-center">
                            <svg class="w-3 h-3 text-gray-400 mx-1" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 9 4-4-4-4"/>
                            </svg>
                            <span class="ml-1 md:ml-2 text-gray-700 font-medium truncate max-w-xs"><?php echo e($recommendation->place_name); ?></span>
                        </div>
                    </li>
                </ol>
            </nav>

            <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
                <div class="grid grid-cols-1 lg:grid-cols-5">
                    <!-- Left Column: Photo -->
                    <div class="lg:col-span-2 bg-gray-100 p-8 flex items-top justify-center relative group">
                         <?php if($recommendation->photo): ?>
                            <a href="<?php echo e(asset('storage/' . $recommendation->photo)); ?>" data-fslightbox>
                                <img src="<?php echo e(asset('storage/' . $recommendation->photo)); ?>" alt="<?php echo e($recommendation->place_name); ?>" class="max-h-[500px] w-auto shadow-lg rounded-lg transform group-hover:scale-105 transition duration-500">
                            </a>
                        <?php else: ?>
                            <div class="h-64 w-full flex flex-col items-center justify-center text-gray-300 border-2 border-dashed border-gray-200 rounded-lg">
                                <svg class="w-16 h-16 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                <span>No Photo Available</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Right Column: Details -->
                    <div class="lg:col-span-3 px-8 pb-10 pt-7 lg:px-12 lg:pt5 lg:pb-12 flex flex-col">
                        <div class="mb-5">
                            <?php if($recommendation->is_indexed): ?>
                                <img src="<?php echo e(asset('storage/recomended_mini.jpg')); ?>" alt="Recommended" class="h-[5rem] mb-2">
                            <?php endif; ?>
                            
                            <h1 class="text-3xl md:text-3xl font-extrabold text-gray-900 mb-2 leading-tight">
                                <?php echo e($recommendation->place_name); ?>

                            </h1>
                            <p class="text-gray-600 text-lg"><i class="fas fa-map-marker-alt mr-1 text-gray-400"></i><?php echo e($recommendation->address); ?></p>
                            <p class="text-gray-600 text-lg mt-1"><i class="fas fa-tag mr-1 text-gray-400"></i><?php echo e($recommendation->recommendationCategory->name ?? '-'); ?></p>
                            <p class="text-gray-500 text-sm mt-2">Dipublikasikan pada <?php echo e($recommendation->published_at->format('d F Y')); ?></p>
                        </div>
                        
                        <?php if($recommendation->description): ?>
                            <div class="prose max-w-none text-gray-700 text-base leading-snug mb-2">
                                <?php echo Str::markdown($recommendation->description); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($recommendation->map_embed_code): ?>
                        <div class="border-t border-gray-100 pt-4 mt-4">
                            <h3 class="text-sm font-semibold text-gray-900 mb-4">Lokasi Peta</h3>
                            <div class="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
                                <?php echo $recommendation->map_embed_code; ?>

                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="border-t border-gray-100 pt-4 mt-1">
                            <h3 class="text-sm font-semibold text-gray-900 mb-4">Direkomendasikan Oleh</h3>
                            <div class="flex items-center space-x-4">
                                <div class="flex-shrink-0">
                                    <?php if($recommendation->user->foto_pelanggan): ?>
                                        <img src="<?php echo e(asset('storage/' . $recommendation->user->foto_pelanggan)); ?>" alt="Foto <?php echo e($recommendation->user->name); ?>" class="w-12 h-12 rounded-full object-cover shadow-md">
                                    <?php else: ?>
                                        <div class="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center text-gray-400">
                                            <svg class="w-10 h-10" fill="currentColor" viewBox="0 0 24 24"><path d="M24 20.993V24H0v-2.993A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <h4 class="text-md font-semibold text-orange-800"><?php echo e($recommendation->user->nama_lengkap); ?></h4>
                                    <p class="text-gray-700 text-sm"><?php echo e($recommendation->user->jabatan_terkini ?? '-'); ?></p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-gray-800 text-white py-6 mt-12 text-center">
        <p>&copy; <?php echo e(date('Y')); ?> INR Team. All rights reserved.</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/fslightbox@latest/index.js"></script>
</body>
</html>
<?php /**PATH D:\xampp8.2\htdocs\react-app\resources\views/recommendations/show.blade.php ENDPATH**/ ?>