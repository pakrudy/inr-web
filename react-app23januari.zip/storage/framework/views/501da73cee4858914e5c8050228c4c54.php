<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Legacy Index - Indonesian Legacy Records</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="antialiased bg-gray-50">

    <?php if (isset($component)) { $__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d)): ?>
<?php $attributes = $__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d; ?>
<?php unset($__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d)): ?>
<?php $component = $__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d; ?>
<?php unset($__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d); ?>
<?php endif; ?>

    <main class="py-16">
        <div class="container mx-auto px-4">
            <h1 class="text-4xl font-extrabold text-center text-gray-900 mb-4">Legacy Index</h1>
            <p class="text-center text-gray-600 mb-6">Jelajahi legacy dan pencapaian yang telah tercatat secara resmi.</p>

            <!-- Search Form -->
            <div class="mb-14 max-w-lg mx-auto">
                <form action="<?php echo e(route('records.index')); ?>" method="GET" class="flex items-center">
                    <input 
                        type="text" 
                        name="search" 
                        placeholder="Cari berdasarkan nama atau judul..." 
                        class="w-full px-4 py-2 border border-gray-300 rounded-l-md focus:ring-indigo-500 focus:border-indigo-500"
                        value="<?php echo e(request('search')); ?>"
                    >
                    <button type="submit" class="bg-orange-600 text-white px-4 py-2 rounded-r-md hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Cari
                    </button>
                </form>
            </div>
            
            <?php if($records->isEmpty()): ?>
                <p class="text-center text-gray-500">Tidak ada legacy yang tersedia untuk ditampilkan.</p>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-lg shadow-sm hover:shadow-lg transition-shadow duration-300 overflow-hidden flex">
                            <!-- Left: Image -->
                            <a href="<?php echo e(route('records.show', $record->id)); ?>" class="block w-1/4 flex-shrink-0 bg-gray-100 ">
                                <?php if($record->photo): ?>
                                    <img src="<?php echo e(asset('storage/' . $record->photo)); ?>" alt="Foto Legacy" class="p-4 h-48 w-38 items-center justify-center">
                                <?php else: ?>
                                    <div class="p-4 h-48 w-38 flex items-center justify-center bg-gray-100 text-gray-300">
                                        <svg class="w-12 h-12" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clip-rule="evenodd"></path></svg>
                                    </div>
                                <?php endif; ?>
                            </a>
                            <!-- Right: Text -->
                            <div class="p-5 flex flex-col justify-center w-2/3">
                                <?php if($record->is_indexed): ?>
                                    <div class="flex items-center text-blue-500 mb-2">
                                        <svg class="w-5 h-5 flex-shrink-0 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                                        </svg>
                                        <span class="text-xs font-bold uppercase">Verified</span>
                                    </div>
                                <?php endif; ?>
                                <h3 class="text-lg font-bold text-gray-900 leading-snug" title="<?php echo e($record->title); ?>">
                                    <a href="<?php echo e(route('records.show', $record->id)); ?>" class="hover:text-orange-700 transition-colors">
                                        <?php echo e($record->title); ?>

                                    </a>
                                </h3>
                                <p class="text-sm text-gray-500 mt-1"><?php echo e($record->category?->name ?? '-'); ?></p>
                                <p class="text-orange-700 font-semibold text-md mt-3"><?php echo e($record->user->nama_lengkap); ?></p>
                                <?php if($record->user->kategori !== 'Lembaga' && $record->user->jabatan_terkini): ?>
                                    <p class="text-sm text-gray-500 mt-0.5"><?php echo e($record->user->jabatan_terkini); ?></p>
                                <?php endif; ?>
                                <p class="text-sm text-gray-500 mt-2"><?php echo e(Str::limit($record->description, 120)); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-12">
                    <?php echo e($records->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </main>

    <footer class="bg-gray-800 text-white py-6 mt-12 text-center">
        <p>&copy; <?php echo e(date('Y')); ?> INR Team. All rights reserved.</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/fslightbox@latest/index.js"></script>
</body>
</html>
<?php /**PATH D:\xampp8.2\htdocs\react-app\resources\views/records/index.blade.php ENDPATH**/ ?>