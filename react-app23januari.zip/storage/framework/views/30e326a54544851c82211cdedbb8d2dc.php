<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Indonesian Legacy Records')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        
        
        
        <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100 flex flex-col">
            <?php if (isset($component)) { $__componentOriginaled925f2ece4de69383c2b0e46accc118 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled925f2ece4de69383c2b0e46accc118 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customer-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customer-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled925f2ece4de69383c2b0e46accc118)): ?>
<?php $attributes = $__attributesOriginaled925f2ece4de69383c2b0e46accc118; ?>
<?php unset($__attributesOriginaled925f2ece4de69383c2b0e46accc118); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled925f2ece4de69383c2b0e46accc118)): ?>
<?php $component = $__componentOriginaled925f2ece4de69383c2b0e46accc118; ?>
<?php unset($__componentOriginaled925f2ece4de69383c2b0e46accc118); ?>
<?php endif; ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-4">
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                        <strong class="font-bold">Success!</strong>
                        <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Page Content -->
            <main class="flex-grow">
                <?php echo e($slot); ?>

            </main>

            <footer class="bg-white mt-8 py-4 text-center text-sm text-gray-500 border-t">
                <p>&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name', 'Indonesian Legacy Records')); ?>. All Rights Reserved.</p>
            </footer>
        </div>
        <script>
            tinymce.init({
                selector: 'textarea.wysiwyg',
                plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount',
                toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table | align lineheight | numlist bulllist indent outdent | emoticons charmap | removeformat',
            });
        </script>
    </body>
</html>
<?php /**PATH D:\xampp8.2\htdocs\react-app\resources\views/components/customer-layout.blade.php ENDPATH**/ ?>