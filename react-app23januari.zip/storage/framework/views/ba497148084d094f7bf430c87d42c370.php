<?php echo e($slot); ?>

<?php /**PATH D:\xampp8.2\htdocs\react-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>