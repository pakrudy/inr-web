<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Recommendation Index - Indonesian Legacy Records</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="antialiased bg-gray-50">

    <?php if (isset($component)) { $__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d)): ?>
<?php $attributes = $__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d; ?>
<?php unset($__attributesOriginal2a045ed9884d6c52d3aecd1ff8abc07d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d)): ?>
<?php $component = $__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d; ?>
<?php unset($__componentOriginal2a045ed9884d6c52d3aecd1ff8abc07d); ?>
<?php endif; ?>

    <main class="py-16">
        <div class="container mx-auto px-4">
            <h1 class="text-4xl font-extrabold text-center text-gray-900 mb-4">Recommendation Index</h1>
            <p class="text-center text-gray-600 mb-6">Jelajahi tempat-tempat yang telah direkomendasikan.</p>

            <!-- Search Form -->
            <div class="mb-14 max-w-lg mx-auto">
                <form action="<?php echo e(route('recommendations.index')); ?>" method="GET" class="flex items-center">
                    <input 
                        type="text" 
                        name="search" 
                        placeholder="Cari berdasarkan nama tempat atau alamat..." 
                        class="w-full px-4 py-2 border border-gray-300 rounded-l-md focus:ring-indigo-500 focus:border-indigo-500"
                        value="<?php echo e(request('search')); ?>"
                    >
                    <button type="submit" class="bg-orange-600 text-white px-4 py-2 rounded-r-md hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Cari
                    </button>
                </form>
            </div>
            
            <?php if($recommendations->isEmpty()): ?>
                <p class="text-center text-gray-500">Tidak ada rekomendasi yang tersedia untuk ditampilkan.</p>
            <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php $__currentLoopData = $recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-lg shadow-sm hover:shadow-lg transition-shadow duration-300 overflow-hidden">
                            <a href="<?php echo e(route('recommendations.show', $recommendation)); ?>">
                                <?php if($recommendation->photo): ?>
                                    <img src="<?php echo e(asset('storage/' . $recommendation->photo)); ?>" alt="Foto Tempat" class="h-56 w-full object-cover">
                                <?php else: ?>
                                    <div class="h-56 w-full flex items-center justify-center bg-gray-100 text-gray-300">
                                        <svg class="w-16 h-16" fill="currentColor" viewBox="0 0 20 20"><path d="M4.055 11.238a.75.75 0 01.2-1.043l7.5-6.25a.75.75 0 01.99 1.125l-7.5 6.25a.75.75 0 01-1.19-.082zM10 12.5a.75.75 0 000-1.5h.75a.75.75 0 000-1.5H10a2.25 2.25 0 00-2.25 2.25V13a.75.75 0 00.75.75h2.25a.75.75 0 000-1.5H11.5v-2.128a.75.75 0 00-1.5 0V11.5h-.75a.75.75 0 00-.75.75V13a2.25 2.25 0 002.25 2.25h.75a.75.75 0 000-1.5H10z"/></svg>
                                    </div>
                                <?php endif; ?>
                            </a>
                            <div class="p-5">
                                <h3 class="text-xl font-bold text-gray-900 flex items-center mb-3" title="<?php echo e($recommendation->place_name); ?>">
                                    <a href="<?php echo e(route('recommendations.show', $recommendation)); ?>" class="hover:text-orange-700 transition-colors">
                                        <?php echo e($recommendation->place_name); ?>

                                    </a>
                                    <?php if($recommendation->is_indexed): ?>
                                        <img src="<?php echo e(asset('storage/recomended_mini.jpg')); ?>" alt="Recommended" class="h-12 w-auto ml-2 flex-shrink-0">
                                    <?php endif; ?>
                                </h3>
                                <p class="text-gray-600 text-sm mt-1 truncate"><i class="fas fa-map-marker-alt mr-1"></i><?php echo e($recommendation->address); ?></p>
                                <p class="text-gray-600 text-sm mt-1 truncate"><i class="fas fa-tag mr-1"></i><?php echo e($recommendation->recommendationCategory->name ?? '-'); ?></p>
                                <!--<p class="text-sm text-gray-500 mt-2">Direkomendasikan oleh: <span class="font-medium text-gray-700"><?php echo e($recommendation->user->name); ?></span></p>-->
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-12">
                    <?php echo e($recommendations->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </main>

    <footer class="bg-gray-800 text-white py-6 mt-12 text-center">
        <p>&copy; <?php echo e(date('Y')); ?> INR Team. All rights reserved.</p>
    </footer>
</body>
</html>
<?php /**PATH D:\xampp8.2\htdocs\react-app\resources\views/recommendations/index.blade.php ENDPATH**/ ?>